
import './App.css';
import { Pavan } from './components/Pavan';

function App() {
  return (
    <div className="App">
      <Pavan/>
     
    </div>
  );
}

export default App;
